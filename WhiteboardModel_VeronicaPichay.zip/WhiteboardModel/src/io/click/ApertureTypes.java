package io.click;

public enum ApertureTypes {

    F22,
    F16,
    F11,
    F8,
    F56,
    F4

}

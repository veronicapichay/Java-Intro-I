package io.click;

public enum WeatherType {
    SNOWSAND,
    SUNNY,
    SLIGHTOVERCAST,
    OVERCAST,
    CLOUDY,
    SUNSET
}

